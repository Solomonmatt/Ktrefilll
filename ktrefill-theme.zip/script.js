const menuToggle = document.querySelector('.menu-toggle');
const siteNav = document.querySelector('.site-nav');

if (menuToggle && siteNav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = siteNav.classList.toggle('active');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.classList.toggle('open', isOpen);
  });
}

const faqItems = document.querySelectorAll('.faq-item');

faqItems.forEach((item) => {
  const button = item.querySelector('.faq-question');
  if (!button) return;

  button.addEventListener('click', () => {
    faqItems.forEach((entry) => {
      if (entry !== item) {
        entry.classList.remove('active');
      }
    });

    item.classList.toggle('active');
  });
});

const counters = document.querySelectorAll('[data-count]');
const animateCounters = () => {
  counters.forEach((counter) => {
    const target = Number(counter.getAttribute('data-count'));
    const duration = 1400;
    const startTime = performance.now();

    const step = (currentTime) => {
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const value = Math.floor(target * eased);
      counter.textContent = `${value}${counter.dataset.suffix || ''}`;

      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        counter.textContent = `${target}${counter.dataset.suffix || ''}`;
      }
    };

    requestAnimationFrame(step);
  });
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      animateCounters();
      observer.disconnect();
    }
  });
}, { threshold: 0.5 });

counters.forEach((counter) => observer.observe(counter));

const year = document.getElementById('year');
if (year) {
  year.textContent = new Date().getFullYear();
}
